var group__group__hal__adc__common =
[
    [ "CYHAL_ADC_MAX_VALUE", "group__group__hal__adc__common.html#ga51d4fd58442f9c1e0804e3cf0b20c46e", null ],
    [ "CYHAL_ADC_RSLT_BAD_ARGUMENT", "group__group__hal__adc__common.html#ga3d8e417cb13c7037656de9a885e6de81", null ],
    [ "CYHAL_ADC_RSLT_FAILED_CLOCK", "group__group__hal__adc__common.html#gac6fa25d6210c13d2d0357f113cb34476", null ],
    [ "CYHAL_ADC_RSLT_FAILED_INIT", "group__group__hal__adc__common.html#ga700ada6b3f2a27d9c971e12806a30c85", null ],
    [ "CYHAL_ADC_RSLT_NO_CHANNELS", "group__group__hal__adc__common.html#gad8d60d07e594780a0063c8fe0c54a73d", null ]
];