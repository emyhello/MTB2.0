var searchData=
[
  ['enumerated_20types',['Enumerated Types',['../group__group__capsense__enums.html',1,'']]]
];
