var searchData=
[
  ['y',['y',['../structcy__stc__capsense__gesture__position__t.html#a3a1c2f83221a848b380ec4c10362187a',1,'cy_stc_capsense_gesture_position_t::y()'],['../structcy__stc__capsense__position__t.html#a29b1ad8aeb8ab133b7696273fbdfa6cf',1,'cy_stc_capsense_position_t::y()'],['../structcy__stc__capsense__ballistic__context__t.html#abadcc7e1af463b1668eb93183cb87252',1,'cy_stc_capsense_ballistic_context_t::y()']]],
  ['ydelta',['yDelta',['../structcy__stc__capsense__widget__context__t.html#a869b23837236045aba13b4fbde082e95',1,'cy_stc_capsense_widget_context_t']]],
  ['yresolution',['yResolution',['../structcy__stc__capsense__widget__config__t.html#ae527a11d29c8deb400a6c2a58d677aee',1,'cy_stc_capsense_widget_config_t']]]
];
