var searchData=
[
  ['result_20type',['Result Type',['../group__group__result.html',1,'']]]
];
