var indexSectionsWithContent =
{
  0: "cru",
  1: "c",
  2: "c",
  3: "ru",
  4: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "functions",
  2: "typedefs",
  3: "groups",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Functions",
  2: "Typedefs",
  3: "Modules",
  4: "Pages"
};

