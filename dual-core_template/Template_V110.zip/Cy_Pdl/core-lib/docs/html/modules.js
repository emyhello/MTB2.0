var modules =
[
    [ "Result Type", "group__group__result.html", "group__group__result" ],
    [ "Utilities", "group__group__utils.html", "group__group__utils" ]
];