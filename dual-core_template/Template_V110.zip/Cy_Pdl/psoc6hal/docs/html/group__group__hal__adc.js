var group__group__hal__adc =
[
    [ "Common", "group__group__hal__adc__common.html", "group__group__hal__adc__common" ],
    [ "ADC Functions", "group__group__hal__adc__functions.html", "group__group__hal__adc__functions" ],
    [ "ADC Channel Functions", "group__group__hal__adc__channel__functions.html", "group__group__hal__adc__channel__functions" ]
];