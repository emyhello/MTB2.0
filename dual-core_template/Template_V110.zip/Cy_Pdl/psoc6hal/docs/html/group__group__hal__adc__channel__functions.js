var group__group__hal__adc__channel__functions =
[
    [ "cyhal_adc_channel_init", "group__group__hal__adc__channel__functions.html#ga873287b496e482c02f7d2c4ce94433e8", null ],
    [ "cyhal_adc_channel_free", "group__group__hal__adc__channel__functions.html#ga55d144073f10cf6b6a1edcf6b9f59c78", null ],
    [ "cyhal_adc_read_u16", "group__group__hal__adc__channel__functions.html#ga2baef8269f13b3c7da46cdabcef650a0", null ]
];