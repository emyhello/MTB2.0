var group__group__capsense__macros__general =
[
    [ "CY_CAPSENSE_MW_VERSION_MAJOR", "group__group__capsense__macros__general.html#ga104c621005040ae8af24f65224291585", null ],
    [ "CY_CAPSENSE_MW_VERSION_MINOR", "group__group__capsense__macros__general.html#gad6ec980865b471c2f2dfb2cdc35d4c2b", null ],
    [ "CY_CAPSENSE_ID", "group__group__capsense__macros__general.html#ga9d6e1a11f2bd6a660ccf4ff767e18186", null ],
    [ "CY_CAPSENSE_BUSY", "group__group__capsense__macros__general.html#gaa3c8ba2488a71e7ab976519e39169929", null ],
    [ "CY_CAPSENSE_NOT_BUSY", "group__group__capsense__macros__general.html#ga1bd45eed2be393b7f53c20f1bae2814e", null ],
    [ "CY_CAPSENSE_ENABLE", "group__group__capsense__macros__general.html#ga24e839ab0e286fd7e0a29e94f400437c", null ],
    [ "CY_CAPSENSE_DISABLE", "group__group__capsense__macros__general.html#ga67314c7f770734272917dd987bfbb970", null ],
    [ "CY_CAPSENSE_SNS_TOUCH_STATUS_MASK", "group__group__capsense__macros__general.html#gae200b7c77b372a6e02221d90ed2d6435", null ],
    [ "CY_CAPSENSE_SNS_PROX_STATUS_MASK", "group__group__capsense__macros__general.html#gaf56cec4f93d99e05d6b9197533a04c4e", null ],
    [ "CY_CAPSENSE_WD_ACTIVE_MASK", "group__group__capsense__macros__general.html#gad47321d5011cc28ee15d2148c62af66f", null ],
    [ "CY_CAPSENSE_WD_DISABLE_MASK", "group__group__capsense__macros__general.html#ga0a84bc1036114a86ad2806f69110709d", null ],
    [ "CY_CAPSENSE_WD_WORKING_MASK", "group__group__capsense__macros__general.html#ga00a019887f9b20124c916b3a2f431fdd", null ]
];