var searchData=
[
  ['vdda',['vdda',['../structcy__stc__capsense__common__config__t.html#a04857de80018693091a81dce3b19bd66',1,'cy_stc_capsense_common_config_t']]],
  ['velocity',['velocity',['../structcy__stc__capsense__csx__touch__history__t.html#a5a32e8b0644a7bc98f45a4b345188810',1,'cy_stc_capsense_csx_touch_history_t']]],
  ['virtualsnsth',['virtualSnsTh',['../structcy__stc__capsense__advanced__centroid__config__t.html#a99998bdcb8adfc186748f5e8ecff0724',1,'cy_stc_capsense_advanced_centroid_config_t::virtualSnsTh()'],['../structcy__stc__capsense__advanced__touchpad__config__t.html#ade2331205a63402295830fb1ed8bd3a7',1,'cy_stc_capsense_advanced_touchpad_config_t::virtualSnsTh()']]],
  ['visitedmap',['visitedMap',['../structcy__stc__capsense__csx__touch__buffer__t.html#a0c72b5063ccfa7e97c086c06d943ffc9',1,'cy_stc_capsense_csx_touch_buffer_t']]],
  ['vref',['vRef',['../structcy__stc__capsense__auto__tune__config__t.html#a50522d0350068cbfba0aeebaff115d9c',1,'cy_stc_capsense_auto_tune_config_t']]]
];
