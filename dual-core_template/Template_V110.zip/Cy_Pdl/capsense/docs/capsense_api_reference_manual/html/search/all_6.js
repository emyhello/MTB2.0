var searchData=
[
  ['gainreg',['gainReg',['../structcy__stc__capsense__idac__gain__table__t.html#ad44c7d56219cb4db0e7aaaba7821fb40',1,'cy_stc_capsense_idac_gain_table_t']]],
  ['gainvalue',['gainValue',['../structcy__stc__capsense__idac__gain__table__t.html#ae0e27b2d2c7a17bde0d7ed7c00bd0074',1,'cy_stc_capsense_idac_gain_table_t']]],
  ['gesturedetected',['gestureDetected',['../structcy__stc__capsense__widget__context__t.html#a1abcf6d1b22d6cc09006eb81576f81f6',1,'cy_stc_capsense_widget_context_t']]],
  ['gesturedirection',['gestureDirection',['../structcy__stc__capsense__widget__context__t.html#a1bd21ada41343af3e4102b85ab62edab',1,'cy_stc_capsense_widget_context_t']]],
  ['gestureenablemask',['gestureEnableMask',['../structcy__stc__capsense__gesture__config__t.html#a47ee76801d9ab0c1c11e057d12fb37cc',1,'cy_stc_capsense_gesture_config_t']]],
  ['gesture_20structures',['Gesture Structures',['../group__group__capsense__gesture__structures.html',1,'']]],
  ['general_20macros',['General Macros',['../group__group__capsense__macros__general.html',1,'']]],
  ['gesture_20macros',['Gesture Macros',['../group__group__capsense__macros__gesture.html',1,'']]]
];
