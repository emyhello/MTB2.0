var searchData=
[
  ['high_2dlevel_20functions',['High-level Functions',['../group__group__capsense__high__level.html',1,'']]],
  ['history',['history',['../structcy__stc__capsense__ofrt__context__t.html#a4df4b5e9a02cba4b6bba8e6c10c2c68e',1,'cy_stc_capsense_ofrt_context_t']]],
  ['hysteresis',['hysteresis',['../structcy__stc__capsense__smartsense__update__thresholds__t.html#a958e9740d154803f7fbf750862d8713c',1,'cy_stc_capsense_smartsense_update_thresholds_t::hysteresis()'],['../structcy__stc__capsense__widget__context__t.html#a6db8e6c147c6b3da087fa96508d8704a',1,'cy_stc_capsense_widget_context_t::hysteresis()']]]
];
