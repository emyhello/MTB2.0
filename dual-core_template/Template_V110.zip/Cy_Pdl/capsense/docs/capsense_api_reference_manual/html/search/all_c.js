var searchData=
[
  ['ofcdcontext',['ofcdContext',['../structcy__stc__capsense__gesture__context__t.html#ab916aaccb1b24a8dc5eee9385d0d2041',1,'cy_stc_capsense_gesture_context_t']]],
  ['ofdccontext',['ofdcContext',['../structcy__stc__capsense__gesture__context__t.html#a41504e9edd68b6aab487492c95b6a059',1,'cy_stc_capsense_gesture_context_t']]],
  ['ofescontext',['ofesContext',['../structcy__stc__capsense__gesture__context__t.html#a34feed1bf649ef82f09da51745d0514e',1,'cy_stc_capsense_gesture_context_t']]],
  ['offlcontext',['offlContext',['../structcy__stc__capsense__gesture__context__t.html#a7a6f0b99bddc8e18cfea0fedb39e00b8',1,'cy_stc_capsense_gesture_context_t']]],
  ['ofrtcontext',['ofrtContext',['../structcy__stc__capsense__gesture__context__t.html#a48dfae93de6b33ba60cdd10f8292e590',1,'cy_stc_capsense_gesture_context_t']]],
  ['ofsccontext',['ofscContext',['../structcy__stc__capsense__gesture__context__t.html#a72755d5985247fd60078900d1482ddfc',1,'cy_stc_capsense_gesture_context_t']]],
  ['ofslcontext',['ofslContext',['../structcy__stc__capsense__gesture__context__t.html#a7f7257503a55d3790ab222a6ac280a85',1,'cy_stc_capsense_gesture_context_t']]],
  ['oldactiveidsmask',['oldActiveIdsMask',['../structcy__stc__capsense__csx__touch__history__t.html#a673eaa945ec772627c954df63b42a89e',1,'cy_stc_capsense_csx_touch_history_t']]],
  ['oldpeak',['oldPeak',['../structcy__stc__capsense__csx__touch__history__t.html#a9cd73499eb9138949da6bd8812a654d1',1,'cy_stc_capsense_csx_touch_history_t']]],
  ['oldpeaknumber',['oldPeakNumber',['../structcy__stc__capsense__csx__touch__history__t.html#aad62c7d9b921294d3caff02bcca10734',1,'cy_stc_capsense_csx_touch_history_t']]],
  ['oldtimestamp',['oldTimestamp',['../structcy__stc__capsense__ballistic__context__t.html#a38d8589f93a3bc5fa8fb53e5076d6da6',1,'cy_stc_capsense_ballistic_context_t']]],
  ['oldtouchnumber',['oldTouchNumber',['../structcy__stc__capsense__ballistic__context__t.html#a74a898f524e561622e4fb8d5b302fa77',1,'cy_stc_capsense_ballistic_context_t']]],
  ['ondebounce',['onDebounce',['../structcy__stc__capsense__widget__context__t.html#a594bf2fb432dbeaa9b23545a9ff3d55a',1,'cy_stc_capsense_widget_context_t']]]
];
