var searchData=
[
  ['wdtouch',['wdTouch',['../structcy__stc__capsense__widget__context__t.html#a8278c09fe62e33e5e460f3064b90e614',1,'cy_stc_capsense_widget_context_t']]],
  ['wdtype',['wdType',['../structcy__stc__capsense__widget__config__t.html#a78fb9e1d1b8c8cdad2d4257f5881ddc2',1,'cy_stc_capsense_widget_config_t']]],
  ['widgetindex',['widgetIndex',['../structcy__stc__active__scan__sns__t.html#a013e17535d7b3ed5bb4268a5baf5863b',1,'cy_stc_active_scan_sns_t']]]
];
