var searchData=
[
  ['macros',['Macros',['../group__group__capsense__macros.html',1,'']]],
  ['miscellaneous_20macros',['Miscellaneous Macros',['../group__group__capsense__macros__miscellaneous.html',1,'']]]
];
