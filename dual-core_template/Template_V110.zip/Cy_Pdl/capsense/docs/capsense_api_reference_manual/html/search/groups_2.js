var searchData=
[
  ['gesture_20structures',['Gesture Structures',['../group__group__capsense__gesture__structures.html',1,'']]],
  ['general_20macros',['General Macros',['../group__group__capsense__macros__general.html',1,'']]],
  ['gesture_20macros',['Gesture Macros',['../group__group__capsense__macros__gesture.html',1,'']]]
];
