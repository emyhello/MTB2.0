var searchData=
[
  ['edge',['edge',['../structcy__stc__capsense__ofes__context__t.html#ac157aeb4721e704a38dff878b34f4bbf',1,'cy_stc_capsense_ofes_context_t']]],
  ['edgeanglemax',['edgeAngleMax',['../structcy__stc__capsense__gesture__config__t.html#a3e6b32e61c14bedfe0dae9fa6fa2ae76',1,'cy_stc_capsense_gesture_config_t']]],
  ['edgecorrectionen',['edgeCorrectionEn',['../structcy__stc__capsense__advanced__centroid__config__t.html#a5101330723664b0878203d70729b0f81',1,'cy_stc_capsense_advanced_centroid_config_t']]],
  ['edgedistancemin',['edgeDistanceMin',['../structcy__stc__capsense__gesture__config__t.html#a18f7465297e8f690506025215800585a',1,'cy_stc_capsense_gesture_config_t']]],
  ['edgeedgesize',['edgeEdgeSize',['../structcy__stc__capsense__gesture__config__t.html#aa9a25c2b003808ad393ca2a00dc3f531',1,'cy_stc_capsense_gesture_config_t']]],
  ['edgetimeoutmax',['edgeTimeoutMax',['../structcy__stc__capsense__gesture__config__t.html#a2b78f409219d6f4de0e86b0554c2ec57',1,'cy_stc_capsense_gesture_config_t']]]
];
