var searchData=
[
  ['pin_2drelated_20macros',['Pin-related Macros',['../group__group__capsense__macros__pin.html',1,'']]],
  ['processing_20macros',['Processing Macros',['../group__group__capsense__macros__process.html',1,'']]]
];
