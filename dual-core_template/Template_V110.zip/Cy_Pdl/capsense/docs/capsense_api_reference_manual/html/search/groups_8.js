var searchData=
[
  ['touch_2drelated_20macros',['Touch-related Macros',['../group__group__capsense__macros__touch.html',1,'']]]
];
