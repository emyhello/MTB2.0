var searchData=
[
  ['negbslnrstcnt',['negBslnRstCnt',['../structcy__stc__capsense__sensor__context__t.html#a0dfea7d7b4a9b3858a203a54df8bc3fc',1,'cy_stc_capsense_sensor_context_t']]],
  ['newactiveidsmask',['newActiveIdsMask',['../structcy__stc__capsense__csx__touch__buffer__t.html#a9267df7cd343b44ee9dddfdf64a4e210',1,'cy_stc_capsense_csx_touch_buffer_t']]],
  ['newpeak',['newPeak',['../structcy__stc__capsense__csx__touch__buffer__t.html#a8ede0076f02b01e43bdf7d01a90e5d8b',1,'cy_stc_capsense_csx_touch_buffer_t']]],
  ['newpeaknumber',['newPeakNumber',['../structcy__stc__capsense__csx__touch__buffer__t.html#a497b8e96e84f765fc258f34f071aa999',1,'cy_stc_capsense_csx_touch_buffer_t']]],
  ['nnoiseth',['nNoiseTh',['../structcy__stc__capsense__smartsense__update__thresholds__t.html#a0e03cc2b5dcfb072e46e2d4a6afb2ef6',1,'cy_stc_capsense_smartsense_update_thresholds_t::nNoiseTh()'],['../structcy__stc__capsense__widget__context__t.html#a6498ae887b0e0a6d8a174e79ed5aacf5',1,'cy_stc_capsense_widget_context_t::nNoiseTh()']]],
  ['noiseth',['noiseTh',['../structcy__stc__capsense__smartsense__update__thresholds__t.html#a6278afa4506e0f81410444bc8bd4ef6e',1,'cy_stc_capsense_smartsense_update_thresholds_t::noiseTh()'],['../structcy__stc__capsense__widget__context__t.html#a8bd80c8460e60bc9437e229329ce63fc',1,'cy_stc_capsense_widget_context_t::noiseTh()']]],
  ['nomovth',['noMovTh',['../structcy__stc__capsense__adaptive__filter__config__t.html#ab838a235c299b6d9ea57bd3fc41568d8',1,'cy_stc_capsense_adaptive_filter_config_t']]],
  ['numcols',['numCols',['../structcy__stc__capsense__widget__config__t.html#af281dfdef5176c9db5e88cf162686ad4',1,'cy_stc_capsense_widget_config_t']]],
  ['numpin',['numPin',['../structcy__stc__capsense__common__config__t.html#af1b66d5becece2209af864547ac16c65',1,'cy_stc_capsense_common_config_t']]],
  ['numpins',['numPins',['../structcy__stc__capsense__electrode__config__t.html#a2ff8c3a5d8d8bd2fe260cf353064f54e',1,'cy_stc_capsense_electrode_config_t']]],
  ['numposition',['numPosition',['../structcy__stc__capsense__gesture__context__t.html#a5f96cbd3fde2fc2007499bdfc5e8ad59',1,'cy_stc_capsense_gesture_context_t::numPosition()'],['../structcy__stc__capsense__touch__t.html#a06915bc608b7177c425659ab61d38513',1,'cy_stc_capsense_touch_t::numPosition()']]],
  ['numpositionlast',['numPositionLast',['../structcy__stc__capsense__gesture__context__t.html#adfc86db072daa3b309979efb5768456d',1,'cy_stc_capsense_gesture_context_t']]],
  ['numrows',['numRows',['../structcy__stc__capsense__widget__config__t.html#a93e1fecbb0649d67dee102b1ef2cd1b8',1,'cy_stc_capsense_widget_config_t']]],
  ['numsns',['numSns',['../structcy__stc__capsense__widget__config__t.html#ae61718f5e9f507beaff5d105e03659a0',1,'cy_stc_capsense_widget_config_t::numSns()'],['../structcy__stc__capsense__common__config__t.html#a21d3bc1dab9651fed220ebdfead85453',1,'cy_stc_capsense_common_config_t::numSns()']]],
  ['numwd',['numWd',['../structcy__stc__capsense__common__config__t.html#a4b2745560f410d1a0dc70797aeec3fab',1,'cy_stc_capsense_common_config_t']]]
];
