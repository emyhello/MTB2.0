var searchData=
[
  ['callbacks',['Callbacks',['../group__group__capsense__callbacks.html',1,'']]],
  ['capsense_20data_20structure',['CapSense Data Structure',['../group__group__capsense__data__structure.html',1,'']]],
  ['capsense_20structures',['CapSense Structures',['../group__group__capsense__structures.html',1,'']]]
];
