var group__group__capsense__macros =
[
    [ "General Macros", "group__group__capsense__macros__general.html", "group__group__capsense__macros__general" ],
    [ "Settings Macros", "group__group__capsense__macros__settings.html", "group__group__capsense__macros__settings" ],
    [ "Pin-related Macros", "group__group__capsense__macros__pin.html", "group__group__capsense__macros__pin" ],
    [ "Processing Macros", "group__group__capsense__macros__process.html", "group__group__capsense__macros__process" ],
    [ "Touch-related Macros", "group__group__capsense__macros__touch.html", "group__group__capsense__macros__touch" ],
    [ "Gesture Macros", "group__group__capsense__macros__gesture.html", "group__group__capsense__macros__gesture" ],
    [ "Miscellaneous Macros", "group__group__capsense__macros__miscellaneous.html", "group__group__capsense__macros__miscellaneous" ]
];