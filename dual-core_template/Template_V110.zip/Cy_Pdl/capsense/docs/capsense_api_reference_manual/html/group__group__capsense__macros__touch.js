var group__group__capsense__macros__touch =
[
    [ "CY_CAPSENSE_POSITION_NONE", "group__group__capsense__macros__touch.html#ga72bcd596f6407f2c35cfe8d92a2a1f6d", null ],
    [ "CY_CAPSENSE_POSITION_ONE", "group__group__capsense__macros__touch.html#ga00e138168b824ee9c4ecf2fa10e648a0", null ],
    [ "CY_CAPSENSE_POSITION_TWO", "group__group__capsense__macros__touch.html#gaa448ccb1551eb0f38f12b1554c5287c4", null ],
    [ "CY_CAPSENSE_POSITION_THREE", "group__group__capsense__macros__touch.html#ga84fe184256d5a95975dbdd25b7388f63", null ],
    [ "CY_CAPSENSE_POSITION_MULTIPLE", "group__group__capsense__macros__touch.html#gaeda92492a42b009327153c1751a030c3", null ],
    [ "CY_CAPSENSE_MAX_CENTROIDS", "group__group__capsense__macros__touch.html#ga4841683021756c1260950771ed54c841", null ],
    [ "CY_CAPSENSE_CSX_TOUCHPAD_MAX_PEAKS", "group__group__capsense__macros__touch.html#ga3858658519030890061b252946477cd8", null ],
    [ "CY_CAPSENSE_CSX_TOUCHPAD_MAX_AGE", "group__group__capsense__macros__touch.html#ga3d55593bb10be928a44a179df5338cf1", null ],
    [ "CY_CAPSENSE_CSX_TOUCHPAD_ID_UNDEFINED", "group__group__capsense__macros__touch.html#gaec66ce283c819f7aaa44cf3886578e81", null ],
    [ "CY_CAPSENSE_CSX_TOUCHPAD_ID_ABSENT", "group__group__capsense__macros__touch.html#gabf7e655ae8cf71bb01a138f55718007c", null ],
    [ "CY_CAPSENSE_CSX_TOUCHPAD_ID_ON_FAIL", "group__group__capsense__macros__touch.html#ga41f9db75b066c5d862d822bea199fe2f", null ],
    [ "CY_CAPSENSE_CSX_TOUCHPAD_ID_MIN", "group__group__capsense__macros__touch.html#gaf79c640a09ef3915083d857011d9c70c", null ],
    [ "CY_CAPSENSE_CSX_TOUCHPAD_ID_MAX", "group__group__capsense__macros__touch.html#ga26736659b0a4f78ffb1dce945b232c04", null ],
    [ "CY_CAPSENSE_CSX_TOUCHPAD_ID_MASK", "group__group__capsense__macros__touch.html#gaa7c78d7d49c6c4e4ce668580f8f1a304", null ],
    [ "CY_CAPSENSE_CSX_TOUCHPAD_Z_MASK", "group__group__capsense__macros__touch.html#ga0649c5861207fdc959f5dc4b05ecfb97", null ],
    [ "CY_CAPSENSE_CSX_TOUCHPAD_AGE_MASK", "group__group__capsense__macros__touch.html#ga7666446ef2e080e96ad3583bb2a83391", null ],
    [ "CY_CAPSENSE_CSX_TOUCHPAD_DEBOUNCE_MASK", "group__group__capsense__macros__touch.html#gaff1a4c6b9875c4c66cb1922952997f7b", null ],
    [ "CY_CAPSENSE_ADVANCED_CENTROID_NO_TOUCHES", "group__group__capsense__macros__touch.html#ga357d64c36840893809b9fa325f9ad6d5", null ],
    [ "CY_CAPSENSE_ADVANCED_CENTROID_POSITION_ERROR", "group__group__capsense__macros__touch.html#ga7178f206572f3066be919024efcd824f", null ]
];