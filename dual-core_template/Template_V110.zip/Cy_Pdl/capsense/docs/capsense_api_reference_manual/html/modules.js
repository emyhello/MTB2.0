var modules =
[
    [ "High-level Functions", "group__group__capsense__high__level.html", "group__group__capsense__high__level" ],
    [ "Low-level Functions", "group__group__capsense__low__level.html", "group__group__capsense__low__level" ],
    [ "CapSense Data Structure", "group__group__capsense__data__structure.html", "group__group__capsense__data__structure" ],
    [ "Enumerated Types", "group__group__capsense__enums.html", "group__group__capsense__enums" ],
    [ "Macros", "group__group__capsense__macros.html", "group__group__capsense__macros" ],
    [ "Callbacks", "group__group__capsense__callbacks.html", null ]
];